@extends('adminlte::page')
@section('title', 'Home')
@section('content_header')
<h1> Painel de Controle</h1>
@endsection