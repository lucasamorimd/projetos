<?php $__env->startSection('title'); ?>
<?php echo e($unidade->nome_unidade); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_header'); ?>
<h1> Informações de Unidade</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-12">
        <div class="card card-profile ">
            <div class="card-header">
                <h2 class="text-center">
                    <?php echo e($unidade->nome_unidade); ?>

                </h2>
            </div>
            <div class="card-body">

                <div class="row">
                    <div class="col">
                        <div class="card">
                            <h4 class="card-header text-center">Médicos da Unidade</h4>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table text-center table-hover table-striped">
                                        <caption>Lista de Médicos dessa Unidade</caption>
                                        <thead>
                                            <tr>
                                                <th scope="col">Nome</th>
                                                <th scope="col">Área de atuação</th>
                                                <th scope="col">CRM</th>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                                                <th scope="col">Editar</th>
                                                <?php endif; ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $medicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($medico->nome_medico); ?></th>
                                                <td><?php echo e($medico->area_atuacao); ?></td>
                                                <td><?php echo e($medico->crm); ?></td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                                                <td> <a href="<?php echo e(route('alterarMedico',$medico->id_medico)); ?>" class="btn btn-primary"><i class="fas fa-user-edit"></i></a></td>
                                                <?php endif; ?>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card">
                            <h4 class="card-header text-center">Servicos da Unidade</h4>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table text-center table-hover table-striped">
                                        <caption>Lista de Serviços dessa Unidade</caption>
                                        <thead>
                                            <tr>
                                                <th scope="col">Nome</th>
                                                <th scope="col">Tipo</th>
                                                <th scope="col">Preço</th>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                                                <th scope="col">Editar</th>
                                                <?php endif; ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $servicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($servico->nome_servico); ?></th>
                                                <td><?php echo e($servico->tipo_servico); ?></td>
                                                <td>R$ <?php echo e(number_format($servico->preco_servico, 2, ',', ' ')); ?></td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                                                <td><a href="<?php echo e(route('excluirServicoUnidade',[$servico->id_servico,$unidade->id_unidade])); ?>" class="btn btn-danger"><i class="fas fa-trash"></i></a></td>
                                                <?php endif; ?>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="card-footer text-muted text-center">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                <a href="<?php echo e(route('alterarUnidade',$unidade->id_unidade)); ?>" class="btn btn-primary">Alterar</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lucas\Desktop\Projeto_mono_repo\clinica-clinicaCMS\resources\views/unidades/detalhar.blade.php ENDPATH**/ ?>