<?php $__env->startSection('title', 'Serviços'); ?>
<?php $__env->startSection('content_header'); ?>
<h1> Serviços <a href="<?php echo e(route('cadastrarServico')); ?>" class="btn btn-primary">Novo Serviço</a></h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <h4 class="card-header text-center">Serviços cadastrados no sistema</h4>
    <div class="card-body">
        <div class="row justify-content-center">
            <?php $__currentLoopData = $servicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <div class="info-box">
                    <span class="info-box-icon bg-info"><i class="fas fa-stethoscope"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text"><a href="<?php echo e(route('detalharServico', $servico->id_servico)); ?>"><?php echo e($servico->nome_servico); ?></a></span>
                        <span class="info-box-number"><?php echo e($servico->tipo_servico); ?></span>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="card-footer text-muted">

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lucas\Desktop\Projeto_mono_repo\clinica-clinicaCMS\resources\views/servicos/home.blade.php ENDPATH**/ ?>