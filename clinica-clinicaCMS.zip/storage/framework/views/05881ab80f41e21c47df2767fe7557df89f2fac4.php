<?php $__env->startSection('title'); ?>
<?php echo e($usuario->nome); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_header'); ?>
<h1><?php echo e($usuario->nome); ?></h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <div class="row  justify-content-center">
            <div class="col-md-6">
                <div class="table-responsive">
                    <table class="table">
                        <thead class="table-dark">
                            <tr>
                            </tr>
                        </thead>
                        <tbody class="text-left">
                            <tr>
                                <th scope="row">Nome: </th>
                                <td><?php echo e($usuario->nome); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">R.G: </th>
                                <td><?php echo e($usuario->rg); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">E-mail: </th>
                                <td><?php echo e($usuario->email); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Telefone: </th>
                                <td><?php echo e($usuario->telefone); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">CEP: </th>
                                <td><?php echo e($usuario->cep); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Endereço: </th>
                                <td><?php echo e($usuario->endereco); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Cidade: </th>
                                <td><?php echo e($usuario->cidade); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Estado: </th>
                                <td><?php echo e($usuario->estado); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Sexo: </th>
                                <td><?php echo e(($usuario->sexo) == 'm' ? 'Masculino':'Feminino'); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Data de Nescimento: </th>
                                <td><?php echo e(date('d/m/Y',strtotime($usuario->data_nascimento))); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Data de Cadastro: </th>
                                <td><?php echo e(date('d/m/Y',strtotime($usuario->data_cadastro))); ?></td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lucas\Desktop\Projeto_mono_repo\clinica-clinicaCMS\resources\views/usuarios/pacientes/detalhar.blade.php ENDPATH**/ ?>