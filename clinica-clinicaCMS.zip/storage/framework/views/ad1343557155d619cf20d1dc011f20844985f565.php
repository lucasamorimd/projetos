<div class="modal-header">
    <h5 class="modal-title" id="exampleModalLabel">Unidade </h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fas fa-times"></i></button>
</div>
<div class="modal-body">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="table-responsive">
                <table class="table">
                    <thead class="table-dark">
                        <tr>
                        </tr>
                    </thead>
                    <tbody class="text-left">
                        <tr>
                            <th scope="row">Nome: </th>
                            <td><?php echo e($unidade->nome_unidade); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Endereço: </th>
                            <td><?php echo e($unidade->endereco_unidade); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Cidade: </th>
                            <td><?php echo e($unidade->cidade_unidade); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Estado </th>
                            <td><?php echo e($unidade->estado_unidade); ?></td>
                        </tr>
                        <tr>
                            <th class="align-middle" scope="row">Telefone:</th>
                            <td><?php echo e($unidade->telefone_unidade); ?> </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
</div><?php /**PATH C:\Users\Lucas\Desktop\Projeto_mono_repo\clinica-clinicaCMS\resources\views/agendamentos/modals/unidade.blade.php ENDPATH**/ ?>