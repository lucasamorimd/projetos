<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content_header'); ?>
<h1> Painel de Controle</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lucas\Desktop\Projeto_mono_repo\clinica-clinicaCMS\resources\views/home.blade.php ENDPATH**/ ?>