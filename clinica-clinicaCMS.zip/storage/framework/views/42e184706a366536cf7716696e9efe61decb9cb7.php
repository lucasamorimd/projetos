<?php $__env->startSection('title','Novo Médico'); ?>
<?php $__env->startSection('content_header'); ?>

<h1><?php echo e($medico->nome_medico); ?> <a class="btn btn-danger" href="<?php echo e(route('excluirMedico',$medico->id_medico)); ?>">Excluir</a></h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h4 class="text-center">Informações</h4>
    </div>
    <div class="card-body">
        <div class="row  justify-content-center">
            <div class="col">
                <form id="cadastrar_medico" action="<?php echo e(route('salvarAlteracaoMedico')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label for="nome" class="col-sm-2 col-form-label">Nome</label>
                        <div class="col-sm-10">
                            <input name="nome" id="nome" type="text" class="form-control " value="<?php echo e($medico->nome_medico); ?>">
                            <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="crm" class="col-sm-2 col-form-label">CRM</label>
                        <div class="col-sm-10">
                            <input name="crm" id="crm" type="text" class="form-control " value="<?php echo e($medico->crm); ?>">
                            <?php $__errorArgs = ['crm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="area_atuacao" class="col-sm-2 col-form-label">Área de Atuação</label>
                        <div class="col-sm-10">
                            <input name="area_atuacao" id="area_atuacao" type="text" class="form-control " value="<?php echo e($medico->area_atuacao); ?>">

                            <?php $__errorArgs = ['area_atuacao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="unidade" class="col-sm-2 col-form-label">Unidade</label>
                        <div class="col-sm-10">
                            <select id="unidade" class="custom-select " name="unidade" readonly>
                                <option selected value="<?php echo e($unidade->id_unidade); ?>"><?php echo e($unidade->nome_unidade); ?></option>
                            </select>
                            <?php $__errorArgs = ['unidade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="servico" class="col-sm-2 col-form-label">Serviços</label>
                        <div class="col-sm-10">
                            <?php $__currentLoopData = $servicos_medico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servico_med): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="custom-control custom-checkbox">
                                <input name="servicos[]" class="custom-control-input" type="checkbox" value="<?php echo e($servico_med->id_servico); ?>" id="defaultCheck<?php echo e($servico_med->id_servico); ?>" checked>
                                <label class="custom-control-label" for="defaultCheck<?php echo e($servico_med->id_servico); ?>">
                                    <?php echo e($servico_med->nome_servico); ?>

                                </label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $servicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="custom-control custom-checkbox">
                                <input name="servicos[]" class="custom-control-input" type="checkbox" value="<?php echo e($servico->id_servico); ?>" id="defaultCheck<?php echo e($servico->id_servico); ?>">
                                <label class="custom-control-label" for="defaultCheck<?php echo e($servico->id_servico); ?>">
                                    <?php echo e($servico->nome_servico); ?>

                                </label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__errorArgs = ['servicos[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    <input type="hidden" value="<?php echo e($medico->id_medico); ?>" name="id_medico" />
                </form>
            </div>
        </div>
        <div class="card-footer text-muted text-center">
            <button class="btn btn-primary" type="submit" onclick="cadastrar_medico()">Salvar</button>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    function cadastrar_medico() {
        var form = document.getElementById('cadastrar_medico')
        form.submit()
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lucas\Desktop\Projeto_mono_repo\clinica-clinicaCMS\resources\views/medicos/alterar.blade.php ENDPATH**/ ?>