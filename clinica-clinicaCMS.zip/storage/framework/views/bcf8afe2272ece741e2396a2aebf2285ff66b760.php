<?php $__env->startSection('title', 'Medicos'); ?>
<?php $__env->startSection('content_header'); ?>
<h1> Medicos <a href="<?php echo e(route('cadastrarMedico')); ?>" class="btn btn-primary">Novo Médico</a></h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <h4 class="card-header text-center">Médicos cadastrados no sistema</h4>
    <div class="card-body">
        <div class="row">
            <?php $__currentLoopData = $medicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <div class="info-box">
                    <span class="info-box-icon bg-info"><i class="fas fa-user-md"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text"><a href="<?php echo e(route('detalharMedico',$medico->id_medico)); ?>"><?php echo e($medico->nome_medico); ?></a></span>
                        <span class="info-box-number">CRM: <?php echo e($medico->crm); ?></span>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="card-footer text-muted">

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lucas\Desktop\Projeto_mono_repo\clinica-clinicaCMS\resources\views/medicos/home.blade.php ENDPATH**/ ?>