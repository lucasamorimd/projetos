<?php $__env->startSection('title'); ?>
<?php echo e($servico->nome_servico); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_header'); ?>
<h1><?php echo e($servico->nome_servico); ?></h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <h4 class="card-header text-center">Dados do Serviço</h4>
    <div class="card-body">
        <div class="row  justify-content-center">
            <div class="col-md-6">
                <div class="table-responsive">
                    <table class="table">
                        <thead class="table-dark">
                            <tr>
                            </tr>
                        </thead>
                        <tbody class="text-left">
                            <tr>
                                <th scope="row">Nome: </th>
                                <td><?php echo e($servico->nome_servico); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Tipo de Serviço: </th>
                                <td><?php echo e($servico->tipo_servico); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Preço do Serviço: </th>
                                <td>R$ <?php echo e(number_format($servico->preco_servico, 2, ',', ' ')); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Tempo de Duração </th>
                                <td><?php echo e($servico->tempo_estimado); ?> horas</td>
                            </tr>
                            <tr>
                                <th class="align-middle" scope="row">Descrição:</th>
                                <td><?php echo e($servico->descricao_servico); ?> </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="card-footer text-muted text-center">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
        <a href="<?php echo e(route('alterarServico',$servico->id_servico)); ?>" class="btn btn-primary">Alterar</a>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lucas\Desktop\Projeto_mono_repo\clinica-clinicaCMS\resources\views/servicos/detalhar.blade.php ENDPATH**/ ?>