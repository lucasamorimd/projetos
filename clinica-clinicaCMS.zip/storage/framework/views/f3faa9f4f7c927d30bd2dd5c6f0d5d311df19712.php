
<?php $__env->startSection('title'); ?>
<?php echo e($agendamento->nome_paciente); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_header'); ?>
<h1>
    Atender <?php echo e($agendamento->nome_paciente); ?>

</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <h2 class="text-center">Formulário de Atendimento</h2>
    </div>
    <div class="card-body">
        <div class="row  justify-content-center">
            <div class="col">
                <form enctype="multipart/form-data" id="atender_pendente" action="<?php echo e(route('salvarAtendimento')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <h4 class="text-center"> informações do paciente</h4>
                    <hr />
                    <div class="form-group row">
                        <label for="nome_paciente" class="col-sm-2 col-form-label">Nome</label>
                        <div class="col-sm-10">
                            <input readonly name="nome_paciente" id="nome_paciente" type="text" class="form-control " value="<?php echo e($agendamento->nome_paciente); ?>">
                            <?php $__errorArgs = ['nome_paciente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="email" class="col-sm-2 col-form-label">Email</label>
                        <div class="col-sm-10">
                            <input readonly name="email" id="email" type="text" class="form-control " value="<?php echo e($agendamento->email_paciente); ?>">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="telefone" class="col-sm-2 col-form-label">Telefone</label>
                        <div class="col-sm-10">
                            <input readonly name="telefone" id="telefone" type="text" class="form-control " value="<?php echo e($agendamento->telefone_paciente); ?>">
                            <?php $__errorArgs = ['telefone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <hr />
                    <h4 class="text-center">Informações do Atendimento</h4>
                    <hr />
                    <div class="form-group row">
                        <label for="data_atendimento" class="col-sm-3 col-form-label">Data do Atendimento</label>
                        <div class="col-sm-9">
                            <input readonly name="data_atendimento" id="data_atendimento" type="text" class="form-control " value="<?php echo e(date('d/m/Y',strtotime($agendamento->data_atendimento))); ?>">

                            <?php $__errorArgs = ['data_atendimento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="hora_atendimento" class="col-sm-3 col-form-label">Horário do Atendimento</label>
                        <div class="col-sm-9">
                            <input readonly name="hora_atendimento" id="hora_atendimento" type="text" class="align-center form-control " value="<?php echo e(date('H:i',strtotime($agendamento->hora_atendimento))); ?>">

                            <?php $__errorArgs = ['hora_atendimento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="data_abertura" class="col-sm-3 col-form-label">Data do Agendamento</label>
                        <div class="col-sm-9">
                            <input readonly name="data_abertura" id="data_abertura" type="text" class="form-control " value="<?php echo e(date('d/m/Y H:i',strtotime($agendamento->data_abertura))); ?>">

                            <?php $__errorArgs = ['data_abertura'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <hr />
                    <h4 class="text-center">Informações do Servço</h4>
                    <hr />
                    <div class="form-group row">
                        <label for="nome_servico" class="col-sm-2 col-form-label">Serviço</label>
                        <div class="col-sm-10">
                            <input readonly name="nome_servico" id="nome_servico" type="text" class="form-control " value="<?php echo e($servico->nome_servico); ?>">
                            <?php $__errorArgs = ['nome_servico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="tipo_servico" class="col-sm-2 col-form-label">Tipo de serviço</label>
                        <div class="col-sm-10">
                            <select id="tipo_servico" class="custom-select " name="tipo_servico">
                                <option value="<?php echo e($servico->tipo_servico); ?>" selected><?php echo e(ucfirst($servico->tipo_servico)); ?></option>
                            </select>
                            <?php $__errorArgs = ['tipo_servico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="tempo_estimado" class="col-sm-2 col-form-label">Tempo de duração</label>
                        <div class="col-sm-10">
                            <input readonly name="tempo_estimado" id="tempo_estimado" type="number" class="form-control " value="<?php echo e($servico->tempo_estimado); ?>">

                            <?php $__errorArgs = ['tempo_estimado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="preco" class="col-sm-2 col-form-label">Preço</label>
                        <div class="col-sm-10">
                            <input readonly name="preco" id="preco" type="number" class="form-control " value="<?php echo e($servico->preco_servico); ?>">
                            <?php $__errorArgs = ['preco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="descricao" class="col-sm-2 col-form-label">Descrição</label>
                        <div class="col-sm-10">
                            <textarea readonly name="descricao" id="descricao" type="text" class="form-control " value="<?php echo e($servico->descricao_servico); ?>"><?php echo e($servico->descricao_servico); ?></textarea>
                            <?php $__errorArgs = ['descricao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-4">
                            Unidade
                            <div class="custom-control custom-checkbox">
                                <input onclick="return false" checked name="unidade" class="custom-control-input" type="checkbox" value="<?php echo e($unidade->id_unidade); ?>" id="unidade<?php echo e($unidade->id_unidade); ?>">
                                <label class="custom-control-label" for="unidade<?php echo e($unidade->id_unidade); ?>">
                                    <?php echo e($unidade->nome_unidade); ?>

                                </label>
                            </div>
                        </div>
                        <div class="col-sm-8">
                            Médico

                            <div class="custom-control custom-checkbox">
                                <input onclick="return false" checked name="medico" class="custom-control-input" type="checkbox" value="<?php echo e($medico->id_medico); ?>" id="medico<?php echo e($medico->id_medico); ?>">
                                <label class="custom-control-label" for="medico<?php echo e($medico->id_medico); ?>">
                                    <?php echo e($medico->nome_medico); ?>

                                </label>
                            </div>

                            <?php $__errorArgs = ['unidades[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    <hr />
                    <h4 class="text-center">Informações do Prontuário</h4>
                    <hr />
                    <div class="form-group row">
                        <label for="customFile" class="col-sm-2 col-form-label">Resultado</label>
                        <div class="col-sm-10">
                            <div class="custom-file">
                                <input name="arquivo_prontuario" type="file" class="custom-file-input" id="customFile">
                                <label class="custom-file-label" for="customFile">Selecionar Arquivo (apenas PDF)</label>
                            </div>
                            <?php $__errorArgs = ['arquivo_prontuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="resumo" class="col-sm-2 col-form-label">Resumo</label>
                        <div class="col-sm-10">
                            <textarea name="resumo" id="resumo" type="text" class="form-control " placeholder="Coloque aqui um resumo do prontuário"></textarea>
                            <?php $__errorArgs = ['resumo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <input type="hidden" name="id_agendamento" value="<?php echo e($agendamento->id_agendamento); ?>">
                </form>
            </div>
        </div>
        <div class="card-footer text-muted text-center">
            <button class="btn btn-primary" type="submit" onclick="atender_pendente()">Salvar</button>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    function atender_pendente() {
        var form = document.getElementById('atender_pendente')
        form.submit()
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lucas\Desktop\Projeto_mono_repo\clinica-clinicaCMS\resources\views/agendamentos/atenderPendente.blade.php ENDPATH**/ ?>