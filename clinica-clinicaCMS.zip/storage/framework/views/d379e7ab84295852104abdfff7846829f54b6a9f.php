<?php $__env->startSection('title'); ?>
<?php echo e($servico->nome_servico); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_header'); ?>
<h1><?php echo e($servico->nome_servico); ?> <?php echo e(Auth::user()->nome_funcionario); ?></h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <h4 class="text-center">Informações do serviço (<?php echo e($servico->nome_servico); ?>)</h4>
    </div>
    <div class="card-body">
        <div class="row  justify-content-center">
            <div class="col">
                <form id="alterar_servico" action="<?php echo e(route('salvarAlteracaoServico')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="form-group row">
                        <label for="nome" class="col-sm-2 col-form-label">Nome</label>
                        <div class="col-sm-10">
                            <input name="nome" id="nome" type="text" class="form-control " value="<?php echo e($servico->nome_servico); ?>">
                            <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="tipo_servico" class="col-sm-2 col-form-label">Tipo de serviço</label>
                        <div class="col-sm-10">
                            <select id="tipo_servico" class="custom-select " name="tipo_servico">
                                <option value="<?php echo e($servico->tipo_servico); ?>" selected><?php echo e(ucfirst($servico->tipo_servico)); ?></option>
                                <option value="exames">Exame</option>
                                <option value="procedimentos">Procedimento</option>
                                <option value="consultas">Consulta</option>
                            </select>
                            <?php $__errorArgs = ['tipo_servico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="tempo_estimado" class="col-sm-2 col-form-label">Tempo de duração</label>
                        <div class="col-sm-10">
                            <input name="tempo_estimado" id="tempo_estimado" type="number" class="form-control " value="<?php echo e($servico->tempo_estimado); ?>">

                            <?php $__errorArgs = ['tempo_estimado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="preco" class="col-sm-2 col-form-label">Preço</label>
                        <div class="col-sm-10">
                            <input name="preco" id="preco" type="number" class="form-control " value="<?php echo e($servico->preco_servico); ?>">
                            <?php $__errorArgs = ['preco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="descricao" class="col-sm-2 col-form-label">Descrição</label>
                        <div class="col-sm-10">
                            <textarea name="descricao" id="descricao" type="text" class="form-control " value="<?php echo e($servico->descricao_servico); ?>"><?php echo e($servico->descricao_servico); ?></textarea>
                            <?php $__errorArgs = ['descricao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group row justify-content-center">
                        <div class="col-sm-4">
                            <div class="custom-control custom-checkbox">
                                <input checked name="unidades[]" class="custom-control-input" type="checkbox" value="<?php echo e($unidade->id_unidade); ?>" id="defaultCheck<?php echo e($unidade->id_unidade); ?>">
                                <label class="custom-control-label" for="defaultCheck<?php echo e($unidade->id_unidade); ?>">
                                    <?php echo e($unidade->nome_unidade); ?>

                                </label>
                            </div>
                        </div>
                        <div class="col-sm-8">
                            Médicos
                            <?php $__currentLoopData = $medicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($medico->id_unidade === $unidade->id_unidade): ?>
                            <div class="custom-control custom-checkbox">
                                <input checked name="medicos[]" class="custom-control-input" type="checkbox" value="<?php echo e($medico->id_medico); ?>" id="medico<?php echo e($medico->id_medico); ?>">
                                <label class="custom-control-label" for="medico<?php echo e($medico->id_medico); ?>">
                                    <?php echo e($medico->nome_medico); ?>

                                </label>
                            </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $medicos_disp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($medico->id_unidade === $unidade->id_unidade): ?>
                            <div class="custom-control custom-checkbox">
                                <input name="medicos[]" class="custom-control-input" type="checkbox" value="<?php echo e($medico->id_medico); ?>" id="medico<?php echo e($medico->id_medico); ?>">
                                <label class="custom-control-label" for="medico<?php echo e($medico->id_medico); ?>">
                                    <?php echo e($medico->nome_medico); ?>

                                </label>
                            </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__errorArgs = ['unidades[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $unidades_disp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group row">
                        <div class="col-sm-4">
                            <div class="custom-control custom-checkbox">
                                <input name="unidades[]" class="custom-control-input" type="checkbox" value="<?php echo e($unidade->id_unidade); ?>" id="unidade<?php echo e($unidade->id_unidade); ?>">
                                <label class="custom-control-label" for="unidade<?php echo e($unidade->id_unidade); ?>">
                                    <?php echo e($unidade->nome_unidade); ?>

                                </label>
                            </div>
                        </div>
                        <div class="col-sm-8">
                            Médicos

                            <?php $__currentLoopData = $medicos_disp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($medico->id_unidade === $unidade->id_unidade): ?>
                            <div class="custom-control custom-checkbox">
                                <input name="medicos[]" class="custom-control-input" type="checkbox" value="<?php echo e($medico->id_medico); ?>" id="medico<?php echo e($medico->id_medico); ?>">
                                <label class="custom-control-label" for="medico<?php echo e($medico->id_medico); ?>">
                                    <?php echo e($medico->nome_medico); ?>

                                </label>
                            </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__errorArgs = ['unidades[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <input type="hidden" name="id_servico" value="<?php echo e($servico->id_servico); ?>">
                </form>
            </div>
        </div>
        <div class="card-footer text-muted text-center">
            <button class="btn btn-primary" type="submit" onclick="alterar_servico()">Salvar</button>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    function alterar_servico() {
        var form = document.getElementById('alterar_servico')
        form.submit()
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page',['teste'=> Auth::user()->nome_funcionario], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lucas\Desktop\Projeto_mono_repo\clinica-clinicaCMS\resources\views/servicos/alterar.blade.php ENDPATH**/ ?>