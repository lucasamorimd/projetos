## Gerenciador do sistema
Essa parte do sistema está sendo desenvolvido para realizar
a interação entre a clínica e o sistema voltado para o paciente. Desenvolvido em laravel,
utilizando o template AdminLTE.

- Possui dois perfis (funcionario e administrador)

## Funcionário
- Perfil: funcionario
- Terá atribuições simples de gerenciar agendamento e visualizar outras configurações

## Administrador
- Perfil : administrador
- Terá todas as atribuições
- CRUD padrão de usuários, serviços, unidades, medicos e agendamentos

