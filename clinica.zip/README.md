
## Sistema de agendamento para clínica
Sistema projetado para:
## Usuário
- Usuário se cadastra
- Agenda serviço (Consulta, Exame ou Procedimento)
- Visualiza Agendamentos

## Clínica
- Registra as Unidades
- Registra os médicos de cada unidade
- Registra Serviços disponíveis em cada Unidade
- Registra os médicos que realizam cada tipo de serviço

