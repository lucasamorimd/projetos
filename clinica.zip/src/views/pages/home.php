

<?php $render('header', $usuario_dados); ?>

<?php $render('hero', $usuario_dados); ?>

<?php $render('footer'); ?>
<?php $render('scripts'); ?>