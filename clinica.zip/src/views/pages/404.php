<?php $render('header_out_home'); ?>
<main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
        <div class="container">

            <ol>
                <li><a href="<?=$base?>">Home</a></li>
                <li>Error</li>
            </ol>
            <h2>404</h2>

        </div>
    </section><!-- End Breadcrumbs -->

    <section class="inner-page">
        <div class="container" data-aos="fade-up">
            <p>
                Página não encontrada.
            </p>
        </div>
    </section>

</main><!-- End #main -->


<?php $render('footer'); ?>
<?php $render('scripts'); ?>
