<script src="<?= $base ?>/assets/vendor/aos/aos.js"></script>
<script src="<?= $base ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= $base ?>/assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="<?= $base ?>/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="<?= $base ?>/assets/vendor/purecounter/purecounter.js"></script>
<script src="<?= $base ?>/assets/vendor/swiper/swiper-bundle.min.js"></script>

<!-- Template Main JS File -->
<script src="<?= $base ?>/assets/js/main.js"></script>

</body>

</html>