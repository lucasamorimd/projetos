<?php
namespace src\models;
use \core\Model;

class Servico extends Model {

}