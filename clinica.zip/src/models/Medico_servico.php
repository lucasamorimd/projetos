<?php
namespace src\models;
use \core\Model;

class Medico_servico extends Model {

}