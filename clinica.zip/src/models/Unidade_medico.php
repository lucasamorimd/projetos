<?php
namespace src\models;
use \core\Model;

class Unidade_medico extends Model {

}