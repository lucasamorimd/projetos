<?php
namespace src\models;
use \core\Model;

class Agendamento extends Model {

}