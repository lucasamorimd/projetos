<?php
namespace src\models;
use \core\Model;

class Medico extends Model {

}